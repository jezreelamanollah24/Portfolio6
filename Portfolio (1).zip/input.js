const words = [
"BSIT Student",
"Web Developer",
"Java Programmer",
"Future Software Engineer"
];

let i = 0;
let j = 0;
let current = "";
let isDeleting = false;

function type(){

current = words[i];

if(!isDeleting){

document.getElementById("typing").textContent =
current.substring(0,j++);

if(j > current.length){

isDeleting = true;

setTimeout(type,1000);

return;

}

}else{

document.getElementById("typing").textContent =
current.substring(0,j--);

if(j < 0){

isDeleting = false;

i++;

if(i == words.length){

i = 0;

}

}

}

setTimeout(type,isDeleting ? 60 : 120);

}

type();

const sections = document.querySelectorAll("section");

window.addEventListener("scroll",()=>{

sections.forEach(section=>{

const top = section.getBoundingClientRect().top;

if(top < window.innerHeight-100){

section.classList.add("show");

}

});

});

sections.forEach(section=>{

section.classList.add("fade");

});